---
name: cpp-engineering-guardrails
description: >-
  Implement, audit and refactor C++ libraries, services and CMake projects. Covers
  ownership, lifetimes, templates, concurrency, API/ABI, FFI and measured performance.
license: MIT
compatibility: A compiler supporting the tools in C++23 mode and CMake 3.20+ to build the optional CLI; target-project standards and external tools are discovered, never assumed.
metadata:
  version: "1.5.0"
  family: "engineering-guardrails"
  hermes:
    tags:
      - cpp
      - guardrails
      - audit
      - refactoring
      - performance
      - memory-safety
---

# C++ engineering guardrails

For a focused fix, locate the failing caller, its implementation and the nearest regression test in one scoped search. Read their matching regions together. Choose one change that fixes the caller and preserves the existing contract, including ownership, borrow validity and state on failure.

When extending a generic API, verify the weakest previously accepted type alongside the new one. For example, a type can support copying and explicitly delete its move constructor. For ABI changes, verify an existing compiled consumer.

Use the project's compiler and standard. Run a reproducer and the affected regression target. Keep verbose build output in a log; inspect the first relevant error on failure and the executed test count on success. Expand the investigation when a caller, configuration or boundary still lacks evidence. Report the change, checks and material gaps.

Read [lifetime](references/memory-lifetime-ub.md) or [ABI](references/api-abi-ffi.md) guidance when the code leaves a contract unclear. Audits are read-only unless edits are requested. For audits, migrations, performance and wider refactors, use the [engineering guide](engineering-guide.md). Compiler audits cover authored .inc/.inl files; use `--include-generated` for intentional generated coverage and [MSVC context](tools/cpp-rails/MSVC.md) for evaluated targets.
