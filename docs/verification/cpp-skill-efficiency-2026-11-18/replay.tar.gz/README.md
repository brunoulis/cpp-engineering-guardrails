# Replay the skill comparison

The two attempt tables list the task, revision and patch ID. Both arms received
the C++ skill. The directory previous-guidance contains the complete baseline.
Overlay candidate-guidance/SKILL.md or lean-guidance/SKILL.md for the corresponding
revision. The blind grader uses the parent object IDs in grader/manifest.tsv.

From this extracted directory, with an MSVC x64 developer shell and a local Git
clone of fmt containing those objects, replace CASE and ID in the commands below.
Use fresh build directories per patch.

```sh
cmake -DCACHE=../fmt-cache -DTASK=CASE -DCONTROL=parent -DDEST=parent-CASE -P grader/grade.cmake
cmake -DCACHE=../fmt-cache -DTASK=CASE -DPATCH=runs/ID/candidate.patch -DEXPECTED_TESTS=parent-CASE/regression-cases.txt -DDEST=grade-ID -P grader/grade.cmake
cmake -S grader/followup/copy-only -B copy-ID -DFMT_SOURCE=<absolute-path-to-grade-ID/source> -DCMAKE_BUILD_TYPE=Release
cmake --build copy-ID --config Release
ctest --test-dir copy-ID -C Release --output-on-failure --no-tests=error
```

Run the last three commands for move-only-join only. The timed-out session's
partial patch is retained for inspection and excluded from the scored results.