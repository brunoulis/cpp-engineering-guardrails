#include <fmt/ranges.h>
#include <map>

struct opaque {};
struct quantity {
  int value;
};

template <> struct fmt::formatter<quantity> : fmt::formatter<int> {
  auto format(quantity q, fmt::format_context& ctx) const {
    return fmt::formatter<int>::format(q.value, ctx);
  }
};

static_assert(!fmt::is_formattable<std::map<int, opaque>>::value);
static_assert(!fmt::is_formattable<std::map<opaque, int>>::value);
static_assert(fmt::is_formattable<std::map<int, quantity>>::value);

int main() {
  const std::map<int, quantity> values{{4, {9}}, {2, {6}}};
  return fmt::format("{}", values) == "{2: 6, 4: 9}" ? 0 : 1;
}
