cmake_minimum_required(VERSION 3.20)
project(map-formattability LANGUAGES CXX)
include("../consumer.cmake")
