cmake_minimum_required(VERSION 3.20)
project(context-args LANGUAGES CXX)
include("../consumer.cmake")
