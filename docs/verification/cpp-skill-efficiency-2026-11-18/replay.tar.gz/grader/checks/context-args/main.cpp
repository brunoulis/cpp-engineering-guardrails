#include <fmt/format.h>
#include <cstdio>
#include <type_traits>

int main() {
  int value = 17;
  auto name = fmt::arg("who", "Ada");
  const auto storage = fmt::make_format_args(value, name);
  fmt::memory_buffer destination;
  const fmt::format_context source(fmt::appender(destination), storage);
  static_assert(std::is_same_v<decltype(source.args()), const fmt::format_args&>);
  try {
    return fmt::vformat("{0}/{who}", source.args()) == "17/Ada" ? 0 : 1;
  } catch (const fmt::format_error& error) {
    std::fprintf(stderr, "%s\n", error.what());
    return 2;
  }
}
