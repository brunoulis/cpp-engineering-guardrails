cmake_minimum_required(VERSION 3.20)
project(compiled-ostreambuf LANGUAGES CXX)
include("../consumer.cmake")
