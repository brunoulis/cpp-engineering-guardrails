#include <fmt/compile.h>
#include <iterator>
#include <sstream>

int main() {
  std::ostringstream stream;
  auto end = fmt::format_to(std::ostreambuf_iterator<char>(stream),
                            FMT_COMPILE("[{}|{:04d}]"), -12, 7);
  *end++ = '!';
  return !end.failed() && stream.str() == "[-12|0007]!" ? 0 : 1;
}
