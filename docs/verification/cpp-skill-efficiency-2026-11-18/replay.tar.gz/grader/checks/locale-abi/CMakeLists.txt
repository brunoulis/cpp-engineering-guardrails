cmake_minimum_required(VERSION 3.20)
project(locale_abi LANGUAGES CXX)
if(NOT MSVC)
  message(FATAL_ERROR "This case requires the MSVC C++ ABI")
endif()
enable_testing()

# git archive 0c9fce2ffefecfdce794e1859584e25877b7b592 (fmt 11.0.2),
# restricted to LICENSE, include/fmt/base.h and include/fmt/format.h.
file(ARCHIVE_EXTRACT INPUT "${CMAKE_CURRENT_SOURCE_DIR}/fmt-11.0.2-headers.tar.gz"
     DESTINATION "${CMAKE_CURRENT_BINARY_DIR}/old-sdk")
add_library(old_caller OBJECT main.cpp)
target_include_directories(old_caller PRIVATE "${CMAKE_CURRENT_BINARY_DIR}/old-sdk/include")
target_compile_features(old_caller PRIVATE cxx_std_20)
target_compile_options(old_caller PRIVATE /utf-8)

add_subdirectory("${FMT_SOURCE}" fmt EXCLUDE_FROM_ALL)
add_executable(consumer $<TARGET_OBJECTS:old_caller>)
target_link_libraries(consumer PRIVATE fmt::fmt)
add_test(NAME old-client COMMAND consumer)
