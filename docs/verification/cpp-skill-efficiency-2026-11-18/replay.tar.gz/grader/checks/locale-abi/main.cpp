#include <fmt/format.h>
#include <locale>

static_assert(FMT_VERSION == 110002, "Compile the application with its original SDK");

class grouped : public std::numpunct<char> {
  char do_thousands_sep() const override { return '_'; }
  std::string do_grouping() const override { return "\3"; }
};

int main() {
  const std::locale loc(std::locale::classic(), new grouped);
  return fmt::format(loc, "{:L}", 1234567) == "1_234_567" ? 0 : 1;
}
