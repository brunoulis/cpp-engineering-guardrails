set(options -G "${GENERATOR}" "-DCMAKE_CXX_COMPILER=${COMPILER}")
if(PLATFORM)
  list(APPEND options -A "${PLATFORM}")
endif()
if(TOOLSET)
  list(APPEND options -T "${TOOLSET}")
endif()
if(MAKE_PROGRAM)
  list(APPEND options "-DCMAKE_MAKE_PROGRAM=${MAKE_PROGRAM}")
endif()

execute_process(
  COMMAND "${CMAKE_COMMAND}" -S "${PROBE}" -B "${BUILD}"
          --warn-uninitialized --check-system-vars ${options} "-DFMT_SOURCE=${FMT_SOURCE}"
  RESULT_VARIABLE status OUTPUT_VARIABLE output ERROR_VARIABLE diagnostics)
if(NOT status EQUAL 0)
  message(FATAL_ERROR "Embedded configure failed:\n${output}\n${diagnostics}")
endif()
if("${output}\n${diagnostics}" MATCHES "uninitialized variable 'FMT_HEADERS'")
  message(FATAL_ERROR "The embedded configure reported:\n${diagnostics}")
endif()
