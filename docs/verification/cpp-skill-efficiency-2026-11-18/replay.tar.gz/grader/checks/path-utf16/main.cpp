#include <fmt/std.h>
#include <filesystem>
#include <string>

int main() {
  using std::filesystem::path;
  // U+1F680 (rocket) followed by U+10437 (Deseret letter yee).
  const path valid(L"a\xD83D\xDE80\xD801\xDC37-z");
  if (fmt::format("{}", valid) != "a\xF0\x9F\x9A\x80\xF0\x90\x90\xB7-z")
    return 1;

  // An unmatched lead and a trailing low surrogate surround a valid pair.
  const path mixed(L"\xD800\xD83D\xDE80.\xDC01");
  const std::string replacement = "\xEF\xBF\xBD";
  return fmt::format("{}", mixed) == replacement + "\xF0\x9F\x9A\x80." + replacement
             ? 0 : 2;
}
