#include <fmt/format.h>
#include <string>
#include <utility>

template <size_t Capacity> bool check() {
  fmt::basic_memory_buffer<char, Capacity> buffer;
  const auto& view = std::as_const(buffer);
  if (!fmt::to_string(view).empty()) return false;
  const std::string payload("data\0more", 9);
  buffer.append(payload.data(), payload.data() + payload.size());
  return fmt::to_string(view) == payload && fmt::to_string(buffer) == payload;
}

int main() {
  return check<fmt::inline_buffer_size>() && check<2>() ? 0 : 1;
}
