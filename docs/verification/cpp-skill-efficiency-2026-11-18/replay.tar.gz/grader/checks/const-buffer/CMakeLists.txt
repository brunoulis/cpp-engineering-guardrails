cmake_minimum_required(VERSION 3.20)
project(const-buffer LANGUAGES CXX)
include("../consumer.cmake")
