cmake_minimum_required(VERSION 3.20)
project(move-only-join LANGUAGES CXX)
include("../consumer.cmake")
