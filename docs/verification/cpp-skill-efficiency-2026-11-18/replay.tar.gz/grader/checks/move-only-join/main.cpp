#include <fmt/ranges.h>
#include <array>
#include <ranges>
#include <sstream>
#include <utility>

int main() {
  std::istringstream input("2 11 4");
  auto values = std::views::istream<int>(input);
  auto joined = fmt::join(values.begin(), values.end(), "|");
  if (fmt::format("{:02}", std::move(joined)) != "02|11|04") return 1;

  std::istringstream empty;
  if (fmt::format("{}", fmt::join(std::views::istream<int>(empty), "/")) != "")
    return 2;
  std::istringstream two("8 9");
  if (fmt::format("{}", fmt::join(std::views::istream<int>(two), "/")) != "8/9")
    return 3;

  const std::array<int, 2> repeatable{3, 5};
  const auto stable = fmt::join(repeatable, "-");
  const auto args = fmt::make_format_args(stable);
  return fmt::vformat("{}", args) == "3-5" && fmt::vformat("{}", args) == "3-5"
             ? 0 : 4;
}
