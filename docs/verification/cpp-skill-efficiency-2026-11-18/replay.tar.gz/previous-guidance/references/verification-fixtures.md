# Native verification fixtures and supported matrix

These are bounded, executable examples. ABI acceptance proves the selected built fixture/consumer pair, allocation assertions prove the tracked PMR workload, and a sanitizer diagnostic proves that the chosen negative was detected. None establishes whole-program safety, general ABI compatibility or a universal performance rule. All supplied consumers, benchmark programs and runners compile as C++23. The shared-library fixture explicitly compiles as C++17.

## Exact-artifact ABI consumer

The [fixture](../examples/abi-contract/CMakeLists.txt) builds five actual shared libraries: v1, compatible v1, incompatible v2, an unversioned layout break and a missing-free-symbol contract. Compatible v1 deliberately changes its internal allocator from `malloc/free` to `new[]/delete[]`; callers always use the paired function from the same loaded module.

The C++23 consumer loads only the canonical supplied artifact via `LoadLibraryExW` or `dlopen`, then verifies the loaded module identity. Before any operation call it inspects fixed-width bootstrap metadata (magic, version, size, alignment and both member offsets) and resolves every required symbol. Rejected cases assert zero operation calls. The v2/layout cases are never called through the old signature, so rejection does not execute a mismatched-layout access. The missing-artifact case never falls back to a search-path library.

Accepted v1 libraries execute real allocation, a hand-derived byte-sum oracle, paired free, live-allocation balance, null argument errors, zero/oversize input errors and reset semantics. RAII frees a successful buffer before unloading. Allocation failure is represented by code 2 but an actual exhausted allocator is not forced. The fixture is single-threaded, uses trusted built libraries, and does not validate arbitrary binaries, cross-architecture loading, compiler/CRT mixing, malicious metadata, C++ vtables or external production consumers. Loading a library is itself native execution; this is an explicitly built local fixture, not an auditor feature.

```console
cmake -S . -B build-contracts -DCMAKE_BUILD_TYPE=Release -DCPP_RAILS_CONTRACT_FIXTURES=ON
cmake --build build-contracts --parallel 2
ctest --test-dir build-contracts -R "^abi-" --output-on-failure --no-tests=error
```

On Windows initialize the installed MSVC developer environment, use `-G Ninja -DCMAKE_CXX_COMPILER=cl`, and run the generated `.exe` with the exact generated `.dll` path. CTest supplies `$<TARGET_FILE:...>` automatically. Multi-config generators additionally need `--config Release` and `ctest -C Release`. `CPP_RAILS_CONTRACT_FIXTURES=OFF` disables these optional fixtures; it does not imply that they passed.

## Allocation and layout workload

The [benchmark](../examples/performance-contract/benchmark.cpp) compares growing array-of-structs, reserved array-of-structs and reserved structure-of-arrays. Both layouts retain the same hot and cold values. The hot-field scan has a value oracle independent of either storage representation; cold fields are checked as well. A counting `std::pmr::memory_resource` records actual allocation requests, requested bytes and peak simultaneous requested bytes, and verifies that storage is released. These counters exclude allocator metadata, other process allocations and RSS.

`allocation-layout-contract --self-test` exercises empty, one-row and 4,096-row cases and asserts deterministic allocation/checksum properties. Data-buffer assertions account for the measured empty-container infrastructure overhead: MSVC Debug iterator proxies themselves allocate through PMR. Raw counters retain these allocations. Normal execution emits three raw CSV samples of setup/validation time and hot-field scan time for 65,536 rows and 32 scans. Checksums escape through output. Timing has no pass/fail threshold and is not asserted by CTest. Setup includes cold-data validation; timings have a fixed scenario order and no controlled CPU/power/load isolation, so do not interpret them as a general speedup claim.

The checked-in [raw Windows sample](../examples/performance-contract/msvc-x64-release-2026-11-17.csv) was executed locally on 2026-11-17 with MSVC 19.51.36260, x64, Windows 11, Release `/O2 /Ob2 /DNDEBUG` and the CMake default dynamic CRT. Each variant produced checksum 1050575968. Growing AoS requested 29 allocations and 17,697,344 bytes in total; reserved AoS requested one allocation, and reserved SoA two, each totaling 4,194,304 bytes. These are observed implementation/workload values, not portable vector-growth requirements. Rerun the executable to obtain current timing rather than treating this artifact as a performance budget.

## Opt-in sanitizer negatives

The default build contains only safe diagnostic-protocol tests and an uninstrumented ownership control which refuses to execute the deliberate defect. Configure explicit negatives in a separate build directory:

```console
# Compatible GCC/Clang host: separate ASan and UBSan negative executables.
cmake -S . -B build-asan-ubsan -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCPP_RAILS_SANITIZER_CONTRACTS=asan-ubsan
cmake --build build-asan-ubsan --parallel 2 --target sanitizer-expect sanitizer-uninstrumented-control sanitizer-ownership-negative sanitizer-overflow-negative
ctest --test-dir build-asan-ubsan -L "sanitizer-negative|sanitizer-protocol" --output-on-failure --no-tests=error

# Separate TSan build. Do not combine with ASan.
cmake -S . -B build-tsan -DCMAKE_BUILD_TYPE=RelWithDebInfo -DCPP_RAILS_SANITIZER_CONTRACTS=tsan
cmake --build build-tsan --parallel 2 --target sanitizer-expect sanitizer-uninstrumented-control sanitizer-race-negative
ctest --test-dir build-tsan -L "sanitizer-negative|sanitizer-protocol" --output-on-failure --no-tests=error
```

MSVC supports the `asan` mode: configure a Release build with `-DCPP_RAILS_SANITIZER_CONTRACTS=asan` and build `sanitizer-expect sanitizer-uninstrumented-control sanitizer-ownership-negative`. UBSan/TSan requests with MSVC fail configuration explicitly. Compiler/linker/runtime availability is mandatory for a requested negative; no skip code turns absence into success. Avoid global sanitizer flags because the explicit uninstrumented control must remain uninstrumented. Sanitizer builds are defect-detection evidence, not benchmark configurations.

The C++23 `sanitizer-expect` runner uses the existing shell-free native process API. A passing negative requires an actually started child, nonzero exit and the exact expected diagnostic family/pattern: ASan heap-use-after-free, UBSan signed integer overflow or TSan data race. A missing executable, runtime initialization failure, ordinary crash, missing instrumentation, clean exit or unrelated diagnostic fails. CTest imposes a 30-second timeout; a hang is a failure. Protocol subprocesses test these branches without UB and are explicitly not sanitizer execution evidence. ASan leak detection is disabled in this narrow ownership-negative test; there is no leak-sanitizer coverage claim.

Reference options: [MSVC ASan build and instrumentation macro](https://learn.microsoft.com/en-us/cpp/sanitizers/asan-building?view=msvc-170), [Clang UBSan](https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html), [Clang TSan supported platforms and runtime](https://clang.llvm.org/docs/ThreadSanitizer.html). Actual selected compiler/runtime commands take precedence over generic documentation.

## Configured CI matrix

| Host/compiler | Configuration | Selected checks |
| --- | --- | --- |
| Ubuntu latest / GCC | Release | Full CTest; actual Clang backend required |
| Ubuntu latest / Clang | Release | Full CTest; actual Clang backend required |
| macOS latest / Apple Clang | Release | Full CTest; semantic evidence depends on discovered backend |
| Windows latest / MSVC x64 | Release | Full CTest; actual Clang backend required |
| Windows latest / MSVC x64 | Debug | Selftest plus ABI, allocation/layout and sanitizer protocol contracts |
| Ubuntu 22.04 / GCC | RelWithDebInfo, `asan-ubsan` | Two actual negative diagnostics plus safe protocol/control tests |
| Ubuntu 22.04 / GCC | RelWithDebInfo, separate `tsan` | Actual race diagnostic plus safe protocol/control tests |

This is the configured matrix in [the workflow](../.github/workflows/skill-ci.yml), not an all-platform/configuration cross-product or an observed hosted success. Missing sanitizer runtimes or incompatible host memory mappings fail the mandatory requested job. Debug semantic/compiler cross-products, macOS/Windows TSan, MSVC UBSan, other architectures and external ABI consumers are not covered by this addition.

Local evidence uses dedicated `cmake-build-contract-fixtures` and `cmake-build-contract-fixtures-debug` directories on Windows/MSVC. The real ASan use-after-free diagnostic was observed with nonzero child exit. Linux UBSan/TSan and hosted jobs were not run locally. If Clang/clang-tidy are absent, semantic protocol tests and a skipped lint-cache test must be reported separately from real analyzer execution; they do not establish backend coverage.
