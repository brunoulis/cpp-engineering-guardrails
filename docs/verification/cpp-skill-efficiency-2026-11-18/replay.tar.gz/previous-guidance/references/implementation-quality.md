# C++ implementation quality

Use for features, bug fixes and code added in an authorized refactor. Deliver the smallest complete change while preserving selected standard/compiler support, ownership, errors and ABI. Clarity and correctness outrank short expressions.

## Before introducing code

Inspect the implementation, all affected callers and real tests/build targets. Search for an existing resource owner, parser, algorithm or container with the required contract. Reuse project facilities first, then supported STL/platform APIs and installed dependencies. Write a small local implementation when those do not fit. Add a dependency or abstraction when a concrete safety, compatibility or maintenance requirement justifies it; replacing a mature parser/crypto library with homemade code is not simplification.

State input/output and invalid/error states, owning versus borrowed values, invalidation, exception guarantees and resource limits. Reuse the existing version/toolchain workflow; a newer STL example does not authorize changing the target's standard.

| Decision | Priority and evidence |
| --- | --- |
| Preserve bounds, initialization, lifetime and cleanup | Correctness gate; trace all success/failure paths |
| Introduce virtual dispatch, generic machinery or a hierarchy | Justify by actual substitution or responsibility, not future possibilities |
| Retain a one-caller RAII wrapper or ABI boundary | Keep when it enforces resource pairing or compatibility |
| Choose layout/allocator/cache changes | Measure representative workloads; fewer lines are not speed evidence |

## Example: compose the existing parser

Given an existing tested C++23 `parse_count(string_view)` returning `expected<uint32_t, Error>`, preserve its exact syntax/range errors and the caller's stream exception policy:

```cpp
std::expected<std::uint32_t, Error> read_count(std::istream& input) {
    std::string line;
    if (!std::getline(input, line)) return std::unexpected(Error::io);
    return parse_count(line);
}
```

The string owns storage until parsing returns; the result must own its values and retain no view into it. A shared static buffer, `atoi`, retained view or Reader/Factory hierarchy changes contracts or adds unjustified state. Keep an existing RAII/parser boundary when it supplies those guarantees.

Verify valid and invalid input, range errors, default EOF/error, configured stream exceptions and consumption of exactly one line. Build with the actual target configuration. Select sanitizers/ABI/consumer checks when the changed boundary needs them; an unexecuted check remains UNVERIFIED.

Before handing off, inspect the diff and callers for duplicate parsing, conversions, redundant state and unnecessary generic APIs. Remove complexity only while preserving checks and useful ownership boundaries.

## Optional cooperation

If an installed Ponytail skill is available and relevant, use it to challenge unnecessary work; otherwise the local decisions above are sufficient. An available Ponytail Review can supply a second pass on the actual change and connected code. Neither integration installs packages/frameworks, changes the user's scope, replaces language contracts or weakens validation, security, accessibility or tests. Keep legitimate abstractions and readable control flow when they earn their cost.

Superpowers can supply implementation/verification discipline and EGM can challenge complex designs; neither is required. Keep the process proportional: an obvious correction needs no new design document or ceremonial checklist. Record substantive reuse/retention decisions and actual checks in the existing handoff.

Upstream context checked 2026-11-17: [Ponytail generation](https://github.com/DietrichGebert/ponytail/blob/96608e078b2d5ea607c5c3b8b5a54d1c1fba6846/skills/ponytail/SKILL.md), [Ponytail Review](https://github.com/DietrichGebert/ponytail/blob/96608e078b2d5ea607c5c3b8b5a54d1c1fba6846/skills/ponytail-review/SKILL.md). The local guidance is an independent adaptation, not a bundled copy or performance claim. [Vercel's rule template](https://github.com/vercel-labs/agent-skills/blob/main/skills/react-best-practices/rules/_template.md) informs the conditional/example format, not language rules. [Anthropic's skill evaluation guidance](https://github.com/anthropics/skills/blob/main/skills/skill-creator/SKILL.md) informs controlled comparison, not proof of an improvement here.


## When removing behavior or changing generated contracts

Use [removal/consumer evidence](intelligent-refactoring.md) when replacing or deleting behavior, [generation authority/freshness](build-dependencies.md) for affected generated data, and [contract-focused verification](testing-verification.md) for independent expected results. Reuse existing handoff slots; unaffected small changes need no extra process.
